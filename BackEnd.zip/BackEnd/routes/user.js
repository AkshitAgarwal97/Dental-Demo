const express = require('express');
const router = express.Router();
const User = require('../module/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const verify = require('../middleware/login')
const multer = require('multer');
const upload = multer({dest: 'uploads/'})

router.post('/user', upload.single('image'), (req,res,next)=>
{
    console.log(req.file)
    bcrypt.hash(req.body.password,10,(err, hash)=>
    {
        if(err)
            {
                return res.status(500).json
                ({
                    error:err
                })
            }
        else
            {
                var user = new User
                ({
                        
                    User_name:req.body.User_name,
                    password:hash,
                    phone: req.body.phone,
                    Email: req.body.Email,
                    userType: req.body.userType
                })
            }
            user.save((err)=>
                {
                    if(err)
                    {
                        res.json({msg: 'Failed to add user'});
                    }
                    else
                    {
                        res.json({msg: 'User added Successfully'});
                    }
                        
                    console.log(user)
                })
            // .then(result=>{
            //     console.log("result is working")
            //     res.status(200).json({
            //         new_user:result
            //     })
            // })
            // .catch(err=>{
            //     console.log("result is not working")
            //     res.status(500).json({
            //         error:err
            //     })
            // })
    })    
});     
    

    


//verify using token from middleware.
    router.get('/abc',verify,(req,res,) =>
    {
        User.find({User_name:req.body.User_name})
        .exec()
        .then(user =>
            {
                res.status(200).json({
                user:result

            })
    })
    })
    // {
    //     res.status(200).json({
    //         message: 'user route working'
    //     })
    // })


    //router put (update user)
    // router.put('/:id', (req,res,next)=>
    // {
    //     console.log(req.params.id);
    //     user.findOneAndUpdate({_id:req.params.id},
    //         {
    //             $set:
    //             {
    //                 User_name:req.body.User_name,
    //                 password:hash,
    //                 phone: req.body.phone,
    //                 Email: req.body.Email,
    //                 userType: req.body.userType
    //             }
    //         })
    // })

    //login
    router.post('/login',(req,res)=>
    {
        
        User.find({User_name:req.body.User_name})
        .exec()
        .then(user =>
            {
                //to check if there is collection
                if(user.length <1)
                {
                    return res.status(401).json 
                    ({
                        msg:'there is no user saved in the database'
                    })
                }
                bcrypt.compare(req.body.password,user[0].password,(err,result)=> 
                {
                    //to check if password matches or not
                    if(!result)
                    {
                        return res.status(401).json
                        ({
                            msg:'Password does not match'
                        })
                    }
                    // if password matches generate token and display the user information
                    if(result)
                    {
                        const token = jwt.sign
                        ({
                            User_name:user[0].User_name,
                            userType: user[0].userType,
                            Email: user[0].Email,
                            phone: user[0].phone,
                            ecpireIn:"1h"
                        },
                        'this is dummy text',
                        // {
                        //     ecpireIn:"1h"
                        // }
                        );
                        //display the user information
                        res.status(200).json
                        ({
                            User_name:user[0].User_name,
                            userType: user[0].userType,
                            Email: user[0].Email,
                            phone: user[0].phone,
                            token:token
                        })
                    }
                })
            })
    })
    // .catch(err=>
    //     {
    //         res.status(500).json
    //         ({
    //             err:err
    //         })
    //     })

module.exports = router;