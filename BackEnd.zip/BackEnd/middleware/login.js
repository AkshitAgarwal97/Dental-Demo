const jwt = require('jsonwebtoken');
const user = require('../module/user');
 

module.exports =async(req,res,next)=>
{
    console.log("Inside mod exports in middleware")
    try
    {   
        console.log("Inside try in middleware")
        //to split tokan from bearer
        const token = req.headers.authorization.slice(" ")[1];
        console.log("afte catch token in middleware")
        console.log(token);
        console.log("after console log token in middleware")
        const verify = jwt.verify(token,'this is dummy text');
        console.log("hello");
        console.log(verify);
        // if(verify.userType == 'admin')
        // {
        //     next();
        // }
        // else 
        // {
        //     return res.status(401).json(
        //         {
        //             msg: 'not admin'
        //         }
        //     )
        // }
    }
    catch(error)
    {
        console.log("Inside catch in middleware")
        return res.status(402).json(
            {
                msg: 'invalid token'
            }
        )
    }

}