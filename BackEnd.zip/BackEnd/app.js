//importing modules
const express =require('express');
const mongoose =require('mongoose');
const bodyparser =require('body-parser');
const cors =require('cors');
const path =require('path');

var app = express();

//route user
const user = require('./routes/user')

//connect to mongose for collection users
mongoose.connect('mongodb://localhost:27017/users');

//connect to mongosedb
mongoose.connect('mongodb://localhost:27017/user');


//on connection
mongoose.connection.on('connected', ()=>{
    console.log('Connected to database mongodb @ 27017')
});


mongoose.connection.on('error',(err)=>{
    if(err)
    {
    console.log('Error in Database connection'+err);
    }
    console.log('Connection failed');
});

//port number
const port = 3000;

//adding middleware
app.use(cors());

//appding body parser
app.use(bodyparser.json());

//static files
app.use(express.static(path.join(__dirname, 'public')));

//routes
app.use('/api', user);

//testing server


app.listen(port,()=>{
    console.log('Server started at port'+port);
});