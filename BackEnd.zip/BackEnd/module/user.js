const { Schema, model } = require("mongoose");

const UserSchema = new Schema({
    User_name:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    phone:{
        type: Number,
        required: true
    },
    Email:{
        type: String,
        require: true
    },
    
});
module.exports = model("user", UserSchema)