import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
form: FormGroup= new FormGroup({
  username:new FormControl(null,[Validators.required, Validators.email]),
  password: new FormControl(null,[Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')])
})
  constructor() { }

  ngOnInit(): void {
  }
  Login(){
    if(!this.form.valid){
      alert("Please fill atleast 8 characters in the password with include atleast one uppercase, one lowercase, a special character like @-# and a numeric value")
    }
    else
    console.log(this.form.value);
  }
  }

